Könyvtárak telepítéséhez információért látogasd meg: http://www.arduino.cc/en/Guide/Libraries
